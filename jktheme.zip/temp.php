<div class="embed-responsive embed-responsive-16by9">
	<iframe class="embed-responsive-item" src="http://member.jagokeuangan.com/wp-content/uploads/2021/05/simulasi-2.mp4?rel=0" allowfullscreen="allowfullscreen"></iframe>
</div>

<p>Maaf file ini hanya bisa diakses oleh member <a href="http://jagokeuangan.com">jagokeuangan.com</a></p>
<p><a href="http://member.jagokeuangan.com/product/jago-keuangan-basic/">Daftar Sekarang</a> atau <a href="http://member.jagokeuangan.com/login">Login</a></p>

